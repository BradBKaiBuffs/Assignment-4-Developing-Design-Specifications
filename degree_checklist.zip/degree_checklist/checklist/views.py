from django.shortcuts import render, get_object_or_404
from .models import Student, Major, Enroll, Requirement, Course, Major_requirement, Major_selection, Course_requirement

# Create your views here.
def index (request):
    return render(request, "base.html")

def student_list(request):
    slist = Student.objects.all()
    student_list = []
    for s in slist:
        student_list.append(s)
    context = {'student_list': student_list}
    return render(request,"checklist/student_list.html", context)

def enroll_list(request):
    elist = Enroll.objects.all()
    enroll_list = []
    for e in elist:
        enroll_list.append(e)
    context = {'enroll_list': enroll_list}
    return render(request,"checklist/enroll_list.html", context)

def course_list(request):
    clist = Course.objects.all()
    course_list = []
    for c in clist:
        course_list.append(c)
    context = {'course_list': course_list}
    return render(request,"checklist/course_list.html", context)

def requirement_list(request):
    rlist = Requirement.objects.all()
    requirement_list = []
    for r in rlist:
        requirement_list.append(r)
    context = {'requirement_list': requirement_list}
    return render(request,"checklist/requirement_list.html", context)

def maj_sel_list(request):
    mslist = Major_selection.objects.all()
    maj_sel_list = []
    for ms in mslist:
        maj_sel_list.append(ms)
    context = {'maj_sel_list': maj_sel_list}
    return render(request,"checklist/maj_sel_list.html", context)

def maj_req_list(request):
    mrlist = Major_requirement.objects.all()
    maj_req_list = []
    for mr in mrlist:
        maj_req_list.append(mr)
    context = {'maj_req_list': maj_req_list}
    return render(request,"checklist/maj_req_list.html", context)

def course_req_list(request):
    crlist = Course_requirement.objects.all()
    course_req_list = []
    for cr in crlist:
        course_req_list.append(cr)
    context = {'course_req_list': course_req_list}
    return render(request,"checklist/course_req_list.html", context)

def major_list(request):
    mlist = Major.objects.all()
    major_list = []
    for m in mlist:
        major_list.append(m)
    context = {'major_list': major_list}
    return render(request,"checklist/major_list.html", context)