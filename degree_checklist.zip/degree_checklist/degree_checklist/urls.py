"""
URL configuration for degree_checklist project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from checklist import views

# added separate pages for each model
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('student/', views.student_list, name='student_list'),
    path('major/', views.major_list, name='major_list'),
    path('enroll/', views.enroll_list, name='enroll_list'),
    path('course/', views.course_list, name='course_list'),
    path('requirement/', views.requirement_list, name='requirement_list'),
    path('major_selection/', views.maj_sel_list, name='maj_sel_list'),
    path('major_requirement/', views.maj_req_list, name='maj_req_list'),
    path('course_requirement/', views.course_req_list, name='course_req_list'),
]
